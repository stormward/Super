﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ComicBookManager.Models
{
    [Table ("ComicBooks")]
    public class ComicBook
    {
        [Column("ComicBookID")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Required(ErrorMessage = "Comic Book ID Required")]
        [Display(Name = "Comic Book ID")]
        public int ComicBookID { get; set; }
        [Column("ComicBookTitle")]
        [Display(Name = "Title")]
        [Required(ErrorMessage = "Title Required")]
        public string ComicBookTitle { get; set; }
    }
}
