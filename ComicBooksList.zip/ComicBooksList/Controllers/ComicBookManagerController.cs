﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ComicBookManager.Models;
using Microsoft.Data.SqlClient;
using System.Configuration;
using Microsoft.EntityFrameworkCore.Query.Internal;
using System.Text;

namespace ComicBookManager.Controllers
{
    public class HomeController : Controller
    {
        private ComicBookContext db = null;
        public HomeController(ComicBookContext db)
        {
            this.db = db;
        }
        public IActionResult List()
        {
            List<ComicBook> model = (from e in db.ComicBooks
                                     orderby e.ComicBookID
                                     select e).ToList();
            StringBuilder table = new StringBuilder();
            SqlConnection con = new SqlConnection();
            //con.ConnectionString = ConfigurationManager.ConnectionStrings[].ToString();
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Select * from [ComicBook]";
            cmd.Connection = con;
            SqlDataReader rd = cmd.ExecuteReader();
            table.Append("<table border='1'>");
            table.Append("<tr><th>Comic Book ID</th><th>Title</th>");
            table.Append("</tr>");

            return View(model);
        }
    }

}
